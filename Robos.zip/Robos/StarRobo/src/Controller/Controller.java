package Controller;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Controller {
	public static void main(String[] args) throws FileNotFoundException, InterruptedException, IOException {

		RadioButton.setRobo();

		while ((RadioButton.getExecucao() == null)) {
			Thread.sleep(1000);
		}

		switch (RadioButton.getExecucao()) {
		case "testarServicosTravada":
			testarServicosTravada.Robo.main(args);
			break;


		default:
			break;

		}
	}
}
