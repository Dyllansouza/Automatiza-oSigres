package testarServicosTravada;

import java.awt.print.Printable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Set;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import testarServicosTravada.Logs;

public class Robo {
	public static void main(String[] args) throws InterruptedException, FileNotFoundException, IOException {

		String user = System.getProperty("user.name");
		InetAddress host = InetAddress.getLocalHost();

		Logger logs = Logs.Logger();
		logs.info("[testarServicosTravada] Inicializando logger...");
		logs.info("[testarServicosTravada] Acessado por host " + host);
		logs.info("[testarServicosTravada] Usu�rio " + user);

		ArrayList<String> lista = Execucoes.readFile();

		for (String numero : lista) {
			Thread.sleep(2000);
			try {

				/**
				######################################################
				## 			Instanciate the webdriver 				##
				## 			with the browser selected.				##
				###################################################### 
				 */
				WebDriver driver = Driver.webDriver("Chrome");

				/**
				 * 
				 * setUrlBase: Set the main URL used for this robot for this page.
				 * 
				 */
				/**
				######################################################
				## 		Set the main URL used for this robot 		##
				###################################################### 
				 */
				Driver.setUrlBase();
				logs.info("[testarServicosTravada] Executando ID " + numero);
				Execucoes.efetuaLogin();
				Thread.sleep(2000);
				
				/**
				######################################################
				##				Pesquisa o ID acesso.				##				
				######################################################						
				*/
				driver.findElement(By.name("templateForm:j_idt103")).sendKeys(numero);
				driver.findElement(By.xpath("//*[@id=\"templateForm:j_idt104\"]/span[1]")).click();
				Thread.sleep(3000);
				
				
				/**
				######################################################
				##				Clica em 'Testar Servi�os'.	 		##				
				######################################################						
				*/
				driver.findElement(By.id("form:j_idt275:20:j_idt278")).click();
				Thread.sleep(3000);
				/**
				######################################################
				##				Verifica se o bot�o Salvar			##
				##					esta habilitado.	 			##				
				######################################################						
				*/
				WebElement salvar = driver.findElement(By.id("j_idt274:j_idt366"));
				if(!salvar.isEnabled()) {
					
					/**
					######################################################
					##				Clica em 'Administra��o' e	 		##	
					##					depois em 'Tarefas'.	 		##				
					######################################################						
					*/
					driver.findElement(By.xpath("//*[@id=\"templateForm:j_idt31_menu\"]/li[7]/a")).click();
					driver.findElement(By.xpath("//*[@id=\"templateForm:j_idt31_menu\"]/li[7]/ul/li[5]")).click();
					
					/**
					######################################################
					##		Pesquisa o ID por Testar Servi�os 	 		##	
					##				e RUNNING e finaliza.				##				
					######################################################						
					*/					
					driver.findElement(By.name("form:j_idt120")).sendKeys(numero);
					driver.findElement(By.name("form:dtTasks")).click();                			 
					driver.findElement(By.xpath("//*[@id=\"form:dtTasks\"]/option[234]")).click();  // Testar Servi�os
					driver.findElement(By.name("form:dtStatus")).click();
					driver.findElement(By.xpath("//*[@id=\"form:dtStatus\"]/option[5]")).click();	// RUNNING					
					driver.findElement(By.name("form:j_idt136")).click();   						// Buscar
					Thread.sleep(2000);
					driver.findElement(By.xpath("//*[@id=\"form:dtTarefas:j_idt138\"]/input")).click(); // CheckAll Box
//					driver.findElement(By.id("form:dtTarefas:j_idt148")).click();					// Finalizar
					
					
					/**
					######################################################
					##				Clica em 'Administra��o' e	 		##	
					##					depois em 'Tarefas'.	 		##				
					######################################################						
					*/
					driver.findElement(By.xpath("//*[@id=\"templateForm:j_idt31_menu\"]/li[7]/a")).click();
					driver.findElement(By.xpath("//*[@id=\"templateForm:j_idt31_menu\"]/li[7]/ul/li[5]")).click();
					
					/**
					######################################################
					##		Pesquisa o ID por Agendar equipamento 		##	
					##				e RUNNING e finaliza.				##				
					######################################################						
					*/					
					driver.findElement(By.name("form:j_idt120")).sendKeys(numero);
					driver.findElement(By.name("form:dtTasks")).click();                			 
					driver.findElement(By.xpath("//*[@id=\"form:dtTasks\"]/option[8]")).click();  // Testar Servi�os
					driver.findElement(By.name("form:dtStatus")).click();
					driver.findElement(By.xpath("//*[@id=\"form:dtStatus\"]/option[5]")).click();	// RUNNING					
					driver.findElement(By.name("form:j_idt136")).click();   						// Buscar
					Thread.sleep(2000);
					driver.findElement(By.xpath("//*[@id=\"form:dtTarefas:j_idt138\"]/input")).click(); // CheckAll Box
//					driver.findElement(By.id("form:dtTarefas:j_idt148")).click();					// Finalizar
					
					/**
					######################################################
					##					Efetua o Logout.		 		##				
					######################################################						
					*/
					driver.findElement(By.id("templateForm:j_idt27")).click();
					Thread.sleep(1000);
					
					/**
					######################################################
					##		Registra o sucesso e fecha o webdriver.	 	##				
					######################################################						
					*/
					testarServicosTravada.Logs.sucesso.add(numero);
					driver.quit();
					logs.info("[testarServicosTravada] Sucesso na execu��o do ID " + numero);
					
				}else {
					/**
					######################################################
					##					Efetua o Logout.		 		##				
					######################################################						
					*/
					driver.findElement(By.id("templateForm:j_idt27")).click();
					Thread.sleep(1000);
					
					/**
					######################################################
					##		Registra o erro e fecha o webdriver.		##				
					######################################################						
					*/
					testarServicosTravada.Logs.erro.add(numero);
					driver.quit();
					logs.info("[testarServicosTravada] Bot�o Salvar habilitado para o ID " + numero);
					continue;
				}
				
			} catch (Exception e) {
				testarServicosTravada.Logs.erro.add(numero);
				logs.info("[RetrieveDados] Erro ao executar ID " + numero);
				Driver.getWebDriver().quit();
				continue;
			}

			if (!testarServicosTravada.Logs.erro.isEmpty()) {
				testarServicosTravada.Logs.gravaErro();
			}
			if (!testarServicosTravada.Logs.sucesso.isEmpty()) {
				testarServicosTravada.Logs.gravaSucesso();
			}
		}
		Logs.close();
	}
}
