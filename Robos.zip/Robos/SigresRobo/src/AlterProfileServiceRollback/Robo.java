package AlterProfileServiceRollback;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import AlterProfileServiceRollback.Logs;

public class Robo {
	public static void main(String[] args) throws InterruptedException, FileNotFoundException, IOException {

		String user = System.getProperty("user.name");
		InetAddress host = InetAddress.getLocalHost();

		Logger logs = Logs.Logger();
		logs.info("[AlterProfileServiceRollback] Inicializando logger...");
		logs.info("[AlterProfileServiceRollback] Acessado por host " + host);
		logs.info("[AlterProfileServiceRollback] Usu�rio " + user);

		ArrayList<String> lista = Execucoes.readFile();
		
		for (String numero : lista) {
			Thread.sleep(2000);
			try  {

				/**
				 * 
				 * Instanciate the webdriver with the browser selected.
				 * 
				 */
				WebDriver driver = Driver.webDriver("Chrome");

				/**
				 * setUrlBase: Set the main URL used for this robot. navigateToPesquisaInstacia:
				 * Metod that navigate to the button 'Pesquisa Instancia'. searchNrc: Search an
				 * 'Instancia' by the current NRC code. setFocus: Set the focus on the new tab
				 * IBM WebSphere MQ Workflow. efetuaLogin: Apply the login and password required
				 * for this page.
				 */
				Driver.setUrlBase();
				Driver.navigateToPesquisaInstacia();
				Driver.searchNrc(numero);
				logs.info("[AlterProfileServiceRollback] Executando NRC " + numero);
				Execucoes.setFocus();
				Thread.sleep(1000);
				Execucoes.efetuaLogin();

				/**
				 * 
				 * Begin the current cenario procedure. Click in element
				 * 'AlterProfileServiceRollback' and Wait page load
				 * 
				 */

				WebElement map1 = driver.findElement(By.cssSelector("map"));
				WebElement area1 = map1.findElement(By.xpath("/html/body/map/area[45]"));
				
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", area1);
				Thread.sleep(2000);

				/**
				 * 
				 * Click in 'For�ar a conclus�o da Atividade' icon
				 * 
				 */
				driver.findElement(By.xpath("/html/body/table/tbody/tr/td[5]/a[3]/img")).click();

				/**
				 * 
				 * Fill in the field 'ERROR.ERROR_CODE' with the value '0'
				 * 
				 */
				driver.findElement(By.xpath("/html/body/form/table/tbody/tr[73]/td[3]/input")).clear();
				driver.findElement(By.xpath("/html/body/form/table/tbody/tr[73]/td[3]/input")).sendKeys("0");

				/**
				 * 
				 * Fill in the field 'ERROR.ERROR_TYPE' with null
				 * 
				 */
				driver.findElement(By.xpath("/html/body/form/table/tbody/tr[74]/td[3]/input")).clear();

				/**
				 * 
				 * Fill in the field 'ERROR.ERROR_INFO' with OK
				 * 
				 */
				driver.findElement(By.xpath("/html/body/form/table/tbody/tr[75]/td[3]/input")).clear();
				driver.findElement(By.xpath("/html/body/form/table/tbody/tr[75]/td[3]/input")).sendKeys("OK");

				/**
				 * 
				 * Fill in the field 'ERROR.CODE_CALLBACK' with '0'
				 * 
				 */
				WebElement searchCode_CallBack = driver
						.findElement(By.xpath("/html/body/form/table/tbody/tr[76]/td[3]/input"));
				if (searchCode_CallBack != null) {
					driver.findElement(By.xpath("/html/body/form/table/tbody/tr[76]/td[3]/input")).clear();
					driver.findElement(By.xpath("/html/body/form/table/tbody/tr[76]/td[3]/input")).sendKeys("0");
				}
				/**
				 * 
				 * Fill in the field 'ERROR.INFO_CALLBACK' with null
				 * 
				 */
				WebElement searchInfo_CallBack = driver
						.findElement(By.xpath("/html/body/form/table/tbody/tr[77]/td[3]/input"));
				if (searchInfo_CallBack != null)
					driver.findElement(By.xpath("/html/body/form/table/tbody/tr[77]/td[3]/input")).clear();

				/**
				 * 
				 * Click in 'For�ar a conclus�o da Atividade' button
				 * 
				 */
				driver.findElement(By.xpath("/html/body/form/input[3]")).click();
				
				/**
				 * 
				 * Click in Logout button
				 */
				driver.findElement(By.xpath("/html/body/table/tbody/tr/td[10]/a/img")).click();
				Thread.sleep(1000);

				/**
				 * Quit and close the webdriver
				 */
				AlterProfileServiceRollback.Logs.sucesso.add(numero);
				driver.quit();
				logs.info("[AlterProfileServiceRollback] Sucesso na execu��o do NRC " + numero);

			} catch (Exception e) {
				AlterProfileServiceRollback.Logs.erro.add(numero);
					logs.info("[AlterProfileServiceRollback] Erro ao executar NRC " + numero);
					Driver.getWebDriver().quit();
					continue;
					
				
			}

		}
		if (!AlterProfileServiceRollback.Logs.erro.isEmpty()) {
			AlterProfileServiceRollback.Logs.gravaErro();
		}
		if (!AlterProfileServiceRollback.Logs.sucesso.isEmpty()) {
			AlterProfileServiceRollback.Logs.gravaSucesso();
		}
		Logs.close();
	}
}
